<?php
include "getGJScores20.php";
?>