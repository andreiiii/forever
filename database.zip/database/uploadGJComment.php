<?php
include "uploadGJComment20.php";
?>