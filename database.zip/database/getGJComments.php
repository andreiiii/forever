<?php
include "getGJComments20.php";
?>