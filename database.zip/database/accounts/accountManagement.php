<h1>Account management tools:</h1>
<a href="changeUsername.php">Change Username</a>
<a href="changePassword.php">Change Password</a>
<h1>Server tools:</h1>
<a href="../tools/levelReupload.php">Level Reupload</a><br>
<a href="../tools/songReupload.php">Song Reupload</a><br>
<a href="../tools/songAdd.php">Add an MP3</a><br>
<a href="../tools/cron.php">Fix Creator Points</a><br>
<a href="../tools/songList.php">Custom Songs List</a><br>
<a href="../tools/modActions.php">Mod Actions List</a><br>
<a href="../tools/packTable.php">Map Packs List</a>
<!--<h1><a href="https://discord.gg/EHYnxVE">CLICK HERE TO JOIN OUR DISCORD SERVER</a></h1>-->