<?php
include "getGJMapPacks20.php";
?>