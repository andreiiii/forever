<?php
include "updateGJUserScore20.php";
?>