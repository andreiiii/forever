# GMDprivateServer
## Geometry Dash Private Server
A PHP server, which should react exactly, how RobTop's server could react...

Supported version of Geometry Dash: 1.0 - 2.1 (so any version of Geometry Dash works, as of writing this [11th February 2017])

Required version of PHP: 5.6 (7.0 - untested, 5.3 - confirmed to not be working)

### Credits
Private Messaging system by someguy28 (even though he needed a ton of help from me... and by a ton I mean A TON)

Base for account settings by someguy28

Using this for XOR encryption - https://github.com/sathoro/php-xor-cipher - (incl/XORCipher.php)

Most of the stuff in generateHash.php has been figured out by pavlukivan and Italian APK Downloader, so credits to them