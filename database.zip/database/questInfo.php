<?php
/*
	QUESTS
*/
//   QUEST 1
$quest1Name="Negr Spek";
$quest1Type=1;
$quest1Amount=100;
$quest1Reward=69;
//   QUEST 2
$quest2Name="Big Mek Spek";
$quest2Type=2;
$quest2Amount=3;
$quest2Reward=69;
//   QUEST 3
$quest3Name="Smakovka";
$quest3Type=3;
$quest3Amount=15;
$quest3Reward=69;
/*
	REWARDS
*/
//SMALL CHEST
$chest1minOrbs = 200;
$chest1maxOrbs = 400;
$chest1minDiamonds = 2;
$chest1maxDiamonds = 10;
$chest1minShards = 1;
$chest1maxShards = 8;
$chest1minKeys = 1;
$chest1maxKeys = 8;
//BIG CHEST
$chest2minOrbs = 2000;
$chest2maxOrbs = 4000;
$chest2minDiamonds = 20;
$chest2maxDiamonds = 100;
$chest2minShards = 1;
$chest2maxShards = 8;
$chest2minKeys = 1;
$chest2maxKeys = 8;
//REWARD TIMES (in seconds)
$chest1wait = 3600;
$chest2wait = 14400
?>